import React, { useState } from "react";
import "./styles.css";

function App() {
  const [domain, setDomain] = useState("AI");
  const [level, setLevel] = useState("Beginner");
  const [result, setResult] = useState(null);

  const generateIdea = async () => {
    const response = await fetch("http://localhost:5000/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ domain, level })
    });

    const data = await response.json();
    setResult(data);
  };

  return (
    <div className="container">
      <h1>🚀 AI Project Idea Generator</h1>

      <select onChange={(e) => setDomain(e.target.value)}>
        <option>AI</option>
        <option>Web</option>
        <option>ML</option>
        <option>Mobile</option>
      </select>

      <select onChange={(e) => setLevel(e.target.value)}>
        <option>Beginner</option>
        <option>Intermediate</option>
        <option>Advanced</option>
      </select>

      <button onClick={generateIdea}>Generate Project</button>

      {result && (
        <div className="result">
          <h2>💡 Idea: {result.idea}</h2>
          <p>Complexity: {result.evaluation.complexity}</p>
          <p>Learning Value: {result.evaluation.learning}</p>
          <p>Resume Impact: {result.evaluation.resume}</p>
        </div>
      )}
    </div>
  );
}

export default App;
