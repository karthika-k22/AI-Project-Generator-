from flask import Flask, request, jsonify
from flask_cors import CORS
import random

app = Flask(__name__)
CORS(app)

PROJECT_IDEAS = {
    "Web": [
        "AI-powered Resume Analyzer",
        "Smart Job Portal with Skill Matching",
        "Personal Finance Tracker with AI Tips"
    ],
    "AI": [
        "AI Project Idea Generator",
        "Chatbot for College Queries",
        "Fake News Detection System"
    ],
    "ML": [
        "House Price Prediction Model",
        "Student Performance Predictor",
        "Spam Email Classifier"
    ],
    "Mobile": [
        "AI Fitness Coach App",
        "Expense Tracker Mobile App",
        "Smart Reminder App"
    ]
}

def evaluate_project(level):
    if level == "Beginner":
        return {
            "complexity": "Low",
            "learning": "High",
            "resume": "Medium"
        }
    elif level == "Intermediate":
        return {
            "complexity": "Medium",
            "learning": "Very High",
            "resume": "High"
        }
    else:
        return {
            "complexity": "High",
            "learning": "Excellent",
            "resume": "Very High"
        }

@app.route("/generate", methods=["POST"])
def generate():
    data = request.json
    domain = data["domain"]
    level = data["level"]

    idea = random.choice(PROJECT_IDEAS.get(domain, ["General AI Project"]))
    evaluation = evaluate_project(level)

    return jsonify({
        "idea": idea,
        "evaluation": evaluation
    })

if __name__ == "__main__":
    app.run(debug=True)
